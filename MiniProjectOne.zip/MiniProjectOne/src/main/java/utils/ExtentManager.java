package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

    private static ExtentReports extent;
    private static ExtentSparkReporter sparkReporter;
    
    // Create an ExtentReports instance
    public static ExtentReports getInstance() {
        if (extent == null) {
            // Specify the report path
            String reportPath = "test-output/ExtentReports/ExtentReport.html";
            sparkReporter = new ExtentSparkReporter(reportPath);
            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);
        }
        return extent;
    }

    // Create an ExtentTest instance for each test
    public static ExtentTest createTest(String testName) {
        return getInstance().createTest(testName);
    }

    // End the report after the tests are done
    public static void endReport() {
        extent.flush();
    }
}

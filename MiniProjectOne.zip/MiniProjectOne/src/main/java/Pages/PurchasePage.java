package Pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PurchasePage {

	WebDriver driver;
	WebDriverWait wait;

    @FindBy(id = "name")
    WebElement nameField;

    @FindBy(id = "country")
    WebElement countryField;

    @FindBy(id = "city")
    WebElement cityField;

    @FindBy(id = "card")
    WebElement cardField;

    @FindBy(id = "month")
    WebElement monthField;

    @FindBy(id = "year")
    WebElement yearField;

    @FindBy(xpath = "//button[text()='Place Order']")
    WebElement placeOrderButton;
    
    
    @FindBy(xpath = "(//a[@id='itemc'])[1]")
	private WebElement choosePhoneCategory;

	@FindBy(xpath = "(//a[@class='hrefch'])[2]")
	private WebElement chooseProductNameOne;
	
	@FindBy(xpath = "//a[contains(text(),'Add to cart')]")
	private WebElement addToCartButton;

	@FindBy(xpath = "//a[@id='cartur']")
	private WebElement cartButton;
    
	@FindBy(xpath = "//button[text()='Purchase']")
	private WebElement purchaseButton;

    @FindBy(xpath = "//h2[text()='Thank you for your purchase!']")
    WebElement purchaseConfirmationMessage;

    public PurchasePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		PageFactory.initElements(driver, this);
	}

    // Method to enter user details
    public void enterUserDetails(String name, String country, String city) {
        nameField.sendKeys(name);
        countryField.sendKeys(country);
        cityField.sendKeys(city);
    }

    // Method to enter payment details
    public void enterPaymentDetails(String cardNumber, String expiryMonth, String expiryYear) {
        cardField.sendKeys(cardNumber);
        monthField.sendKeys(expiryMonth);
        yearField.sendKeys(expiryYear);
    }

    // Method to complete the purchase
    public void placeOrder() {
        placeOrderButton.click();
    }
    public void clickPurchaseButton() {
    	purchaseButton.click();
    }

    // Method to verify purchase confirmation
    public String verifyPurchaseConfirmation() {
        return purchaseConfirmationMessage.getText();
    }
    
    public void addProductToCart() {
		try {
			wait.until(ExpectedConditions.visibilityOf(choosePhoneCategory));
			choosePhoneCategory.click();
			wait.until(ExpectedConditions.elementToBeClickable(chooseProductNameOne));
			chooseProductNameOne.click();
			wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));
			addToCartButton.click();
			Thread.sleep(2000);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			wait.until(ExpectedConditions.visibilityOf(cartButton));
			cartButton.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Error clicking product: " + e.getMessage());
		}
	}
    
    
}

package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class ProductDisplayAndCategories {

	WebDriver driver;
	WebDriverWait wait;

	// Web elements on the homepage
	@FindBy(id = "login2")
	private WebElement loginButton;

	@FindBy(id = "loginusername")
	private WebElement usernameField;

	@FindBy(id = "loginpassword")
	private WebElement passwordField;

	@FindBy(xpath = "//button[contains(text(),'Log in')]")
	private WebElement submitButton;
	
	@FindBy(id = "logout2")
    private WebElement logoutButton;

	@FindBy(xpath = "//a[contains(text(),'Welcome subaguvi@gmail.com')]")
	private WebElement welcomeText;

	@FindBy(xpath = "//a[@href='index.html']")
	private WebElement homeButton;

	@FindBy(xpath = "//a[contains(text(),'Contact')]")
	private WebElement contactButton;

	@FindBy(xpath = "//a[contains(text(),'Phones')]")
	private WebElement phonesCategoryButton;

	@FindBy(xpath = "//a[contains(text(),'Laptops')]")
	private WebElement laptopsCategoryButton;

	@FindBy(xpath = "//a[contains(text(),'Monitors')]")
	private WebElement monitorsCategoryButton;

	@FindBy(xpath = "(//img)[1]")
	private WebElement applicationLogo;

	@FindBy(xpath = "(//div[@id='navbarExample']/ul/li/a)[1]")
	private WebElement menuItems1;
	
	@FindBy(xpath = "(//div[@id='navbarExample']/ul/li/a)[2]")
	private WebElement menuItems2;
	
	@FindBy(xpath = "(//div[@id='navbarExample']/ul/li/a)[3]")
	private WebElement menuItems3;
	
	@FindBy(xpath = "(//div[@id='navbarExample']/ul/li/a)[4]")
	private WebElement menuItems4;
	
	@FindBy(xpath = "(//div[@id='navbarExample']/ul/li/a)[6]")
	private WebElement menuItems5;
	
	@FindBy(xpath = "(//div[@id='navbarExample']/ul/li/a)[7]")
	private WebElement menuItems6;
	
	@FindBy(xpath = "(//button[contains(text(),'Close')])[3]")
    private WebElement logincloseButton;

	public ProductDisplayAndCategories(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		PageFactory.initElements(driver, this);
	}

	public void login(String username, String password) {
		loginButton.click();
		wait.until(ExpectedConditions.visibilityOf(usernameField));
		usernameField.sendKeys(username);
		passwordField.sendKeys(password);
		submitButton.click();
	}

	// Method to verify that the welcome message is displayed
	public boolean isWelcomeTextDisplayed() {
		try {
			wait.until(ExpectedConditions.visibilityOf(welcomeText));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	   public boolean isLogoutButtonVisible() {
	        try {
	            wait.until(ExpectedConditions.visibilityOf(logoutButton));
	            return logoutButton.isDisplayed();
	        } catch (Exception e) {
	            return false;
	        }
	    }

	// Method to verify that all menu items are displayed
	public boolean areMenuItemsDisplayed() {
		try {
			wait.until(ExpectedConditions.visibilityOf(menuItems1));
			wait.until(ExpectedConditions.visibilityOf(menuItems2));
			wait.until(ExpectedConditions.visibilityOf(menuItems3));
			wait.until(ExpectedConditions.visibilityOf(menuItems4));
			wait.until(ExpectedConditions.visibilityOf(menuItems5));
			wait.until(ExpectedConditions.visibilityOf(menuItems6));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	 public void loginClose() {
	    	logincloseButton.click();
		}

	// Method to verify that the categories are displayed
	public boolean areCategoriesDisplayed() {
		try {
			wait.until(ExpectedConditions.visibilityOf(phonesCategoryButton));
			wait.until(ExpectedConditions.visibilityOf(laptopsCategoryButton));
			wait.until(ExpectedConditions.visibilityOf(monitorsCategoryButton));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Method to verify that the application logo is displayed
	public boolean isLogoDisplayed() {
		try {
			wait.until(ExpectedConditions.visibilityOf(applicationLogo));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}

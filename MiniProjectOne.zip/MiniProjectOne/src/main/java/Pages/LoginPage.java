package Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class LoginPage {

    WebDriver driver;
    WebDriverWait wait;

    // Web elements for login
    @FindBy(id = "login2")
    private WebElement loginButton;

    @FindBy(id = "loginusername")
    private WebElement usernameField;

    @FindBy(id = "loginpassword")
    private WebElement passwordField;

    @FindBy(xpath = "//button[contains(text(),'Log in')]")
    private WebElement submitButton;

    @FindBy(id = "logout2")
    private WebElement logoutButton;

    @FindBy(xpath = "(//a[@href='index.html'])[1]")
    private WebElement homepageButton;
    
    @FindBy(xpath = "(//button[contains(text(),'Close')])[3]")
    private WebElement logincloseButton;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    // Method to check if Login button is visible
    public boolean isLoginButtonVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(loginButton));
            return loginButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Method to click on Login button
    public void clickLoginButton() {
        loginButton.click();
    }

    // Method to enter credentials and login
    public void login(String username, String password) {
        wait.until(ExpectedConditions.visibilityOf(usernameField));
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        submitButton.click();
    }

    // Method to check if the Logout button is visible (indicating successful login)
    public boolean isLogoutButtonVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(logoutButton));
            return logoutButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Method to check if redirected to homepage after login
    public void goToHomePage() {
        homepageButton.click();
    }
    
    public void loginClose() {
    	logincloseButton.click();
	}
}

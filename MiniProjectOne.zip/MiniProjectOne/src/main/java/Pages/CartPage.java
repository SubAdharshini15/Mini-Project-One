package Pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
//import java.util.List;
import java.util.List;

public class CartPage {

	WebDriver driver;
	WebDriverWait wait;

	@FindBy(xpath = "(//a[@id='itemc'])[1]")
	private WebElement choosePhoneCategory;

	@FindBy(xpath = "(//a[@class='hrefch'])[2]")
	private WebElement chooseProductNameOne;
	
	@FindBy(xpath = "(//a[@class='hrefch'])[4]")
	private WebElement chooseProductNameTwo;
	
	@FindBy(xpath = "//a[contains(text(),'Home')]")
	private WebElement homeButton;

	@FindBy(xpath = "//a[contains(text(),'Add to cart')]")
	private WebElement addToCartButton;

	@FindBy(xpath = "//a[@id='cartur']")
	private WebElement cartButton;

	@FindBy(xpath = "(//a[contains(text(),'Delete')])[1]")
	private WebElement deleteButton;
    
	@FindBy(xpath = "//h3[@id='totalp']")
	private WebElement totalPrice;
	
	@FindBy(xpath = "//tbody[@id='tbodyid']")
	private WebElement emptyCart;
	
	public CartPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		PageFactory.initElements(driver, this);
	}

	// Method to click on a product to go to the product details page
	public void addProductOne() {
		try {
			wait.until(ExpectedConditions.visibilityOf(choosePhoneCategory));
			choosePhoneCategory.click();
			wait.until(ExpectedConditions.elementToBeClickable(chooseProductNameOne));
			chooseProductNameOne.click();
		} catch (Exception e) {
			System.out.println("Error clicking product: " + e.getMessage());
		}
	}
	
	public void addProductTwo() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(homeButton));
			homeButton.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(choosePhoneCategory));
			choosePhoneCategory.click();
			wait.until(ExpectedConditions.elementToBeClickable(chooseProductNameTwo));
			chooseProductNameTwo.click();
		} catch (Exception e) {
			System.out.println("Error clicking product: " + e.getMessage());
		}
	}
		

	// Method to add a product to the cart
	public void addToCart() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));
			addToCartButton.click();
			Thread.sleep(2000);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			wait.until(ExpectedConditions.visibilityOf(cartButton));
			cartButton.click();
			Thread.sleep(2000);

		} catch (Exception e) {
			System.out.println("Error adding product to cart: " + e.getMessage());
		}
	}

	public void deleteItemFromCart() {
		try {
			List<WebElement> rows = driver.findElements(By.xpath("//tbody[@id='tbodyid']/tr"));

			// Loop through all the rows and print the content
			for (int i = 0; i < rows.size(); i++) {
				WebElement row = rows.get(i);
				System.out.println("Row " + (i + 1) + ": " + row.getText());
				
			}
			System.out.println("========================================");
			System.out.println("Total number of Items Present in Cart: " + rows.size());
			System.out.println("========================================");
			
			wait.until(ExpectedConditions.visibilityOf(totalPrice));
			System.out.println("Total Price Of added items in cart  : " +totalPrice.getText());
			System.out.println("========================================");
			
			//Click delete button of first item present in cart
			wait.until(ExpectedConditions.visibilityOf(deleteButton));
			deleteButton.click();
			Thread.sleep(2000);
			System.out.println("After deleting the item from Cart");
			Thread.sleep(5000);
			
			List<WebElement> rows1 = driver.findElements(By.xpath("//tbody[@id='tbodyid']/tr"));
			//After delete one item from cart
			for (int i = 0; i < rows1.size(); i++) {
				WebElement row1 = rows1.get(i);
				System.out.println("Row " + (i + 1) + ": " + row1.getText());
			}
			System.out.println("Total number of Items Present in Cart: " + rows1.size());
			System.out.println("========================================");
			

		} catch (Exception e) {
			System.out.println("Error Deleting product from cart: " + e.getMessage());
		}
	}

  public int totalPriceAfterModification() {
	  try {
		  wait.until(ExpectedConditions.visibilityOf(totalPrice));
			System.out.println("Total Price Of added item in cart after modification  : " + totalPrice.getText());
			System.out.println("========================================");
		return 1;
	} catch (Exception e) {
		System.out.println("Error price is not modified after deletion of item from cart");
		return 0;
	}
  }
  
  public boolean isCartEmpty() {
	  try {
		  wait.until(ExpectedConditions.visibilityOf(deleteButton));
		  deleteButton.click();
		  Thread.sleep(2000);
		  wait.until(ExpectedConditions.visibilityOf(emptyCart));
		  Thread.sleep(2000);
		  System.out.println("Cart is Empty");
		  return true;
	} catch (Exception e) {
		System.out.println("Error Cart is not empty");
		return false;
	}
	  
  }
  
}


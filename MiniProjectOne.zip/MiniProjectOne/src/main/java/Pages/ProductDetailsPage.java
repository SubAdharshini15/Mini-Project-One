package Pages;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import java.util.List;

public class ProductDetailsPage {

    WebDriver driver;
    WebDriverWait wait;

    @FindBy(xpath = "(//a[@id='itemc'])[1]")
    private WebElement choosePhoneCategory;
    
    // Web elements for the product details page
    @FindBy(xpath = "(//a[@class='hrefch'])[2]")
    private WebElement chooseProductName;
    
    @FindBy(xpath = "//h2[@class='name']")
    private WebElement productName;
    
    @FindBy(xpath = "//h3[@class='price-container']")
    private WebElement productPrice;

    @FindBy(xpath = "//div[@id='more-information']")
    private WebElement productDescription;

    @FindBy(xpath = "//a[contains(text(),'Add to cart')]")
    private WebElement addToCartButton;

    @FindBy(xpath = "//a[@id='cartur']")
    private WebElement cartButton;

    @FindBy(xpath = "//button[contains(text(),'Place Order')]")
    private WebElement proceedToCheckoutButton;

    public ProductDetailsPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    // Method to click on a product to go to the product details page
    public void clickOnProduct() {
        try {
        	wait.until(ExpectedConditions.visibilityOf(choosePhoneCategory));
        	choosePhoneCategory.click();
            wait.until(ExpectedConditions.elementToBeClickable(chooseProductName));
            chooseProductName.click();
        } catch (Exception e) {
            System.out.println("Error clicking product: " + e.getMessage());
        }
    }

    // Method to verify product details (name, price, description)
    public boolean verifyProductDetails(String expectedName, String expectedPrice, String expectedDescription) {
        try {
            wait.until(ExpectedConditions.visibilityOf(productName));
            String actualName = productName.getText();
            wait.until(ExpectedConditions.visibilityOf(productPrice));
            String actualPrice = productPrice.getText();
            wait.until(ExpectedConditions.visibilityOf(productDescription));
            String actualDescription = productDescription.getText().replaceAll("\\s+", " ").trim();  // Sanitizing description
            
            System.out.println("Actual Name: " + actualName);
            System.out.println("Actual Price: " + actualPrice);
            System.out.println("Actual Description: " + actualDescription);
            String expectedDescriptionSanitized = expectedDescription.replaceAll("\\s+", " ").trim();  // Sanitizing expected description
            
            return actualName.equals(expectedName) && actualPrice.equals(expectedPrice) && actualDescription.equals(expectedDescriptionSanitized);
        } catch (Exception e) {
            return false;
        }
    }
 
    // Method to add a product to the cart
    public void addToCart() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));
            addToCartButton.click();
            Thread.sleep(2000);
            Alert alert = driver.switchTo().alert();
            alert.accept();

        } catch (Exception e) {
            System.out.println("Error adding product to cart: " + e.getMessage());
        }
    }

    // Method to get the cart count (to verify if the product is added)
    public int getCartItemCount() {
        try {
            wait.until(ExpectedConditions.visibilityOf(cartButton));
            cartButton.click();
            Thread.sleep(5000);
  
            List<WebElement> rows = driver.findElements(By.xpath("//tbody[@id='tbodyid']/tr"));

            // Loop through all the rows and print the content
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                System.out.println("Row " + (i + 1) + ": " + row.getText());
            }

            // Print the count of rows
            System.out.println("Total number of rows: " + rows.size());
            return rows.size();
        } catch (Exception e) {
            return 0;
        }
    }
}



package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class SignUpPage {

    WebDriver driver;
    WebDriverWait wait;

    // Constructor to initialize web driver and wait
    public SignUpPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    // Web Elements on the homepage
    @FindBy(id = "signin2")  
    private WebElement signUpButton;

    @FindBy(id = "sign-username") 
    private WebElement signUpUsername;

    @FindBy(id = "sign-password") 
    private WebElement signUpPassword;

    @FindBy(xpath = "//button[text()='Sign up']") 
    private WebElement signUpConfirmButton;

    // Methods to interact with the elements
    public boolean isSignUpButtonVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(signUpButton));
            return signUpButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void clickSignUpButton() {
        wait.until(ExpectedConditions.elementToBeClickable(signUpButton));
        signUpButton.click();
    }


    // Method to perform sign-up action
    public void signUp(String username, String password) {
        wait.until(ExpectedConditions.visibilityOf(signUpUsername));
        signUpUsername.sendKeys(username);
        signUpPassword.sendKeys(password);
        signUpConfirmButton.click();
    }

    // Capture screenshot in case of failure
    public void captureScreenshot(String fileName) {
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destFile = new File("./screenshots/" + fileName + ".png");
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

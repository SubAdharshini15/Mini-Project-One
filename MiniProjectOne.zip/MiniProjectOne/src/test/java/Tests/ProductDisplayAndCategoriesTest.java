package Tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import utils.ExtentManager;
import com.aventstack.extentreports.ExtentTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import Pages.ProductDisplayAndCategories;

public class ProductDisplayAndCategoriesTest {

    WebDriver driver;
    ProductDisplayAndCategories productPage;
    ExtentTest test;  // ExtentTest instance for logging test steps

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");

        // Initialize the HomePage class
        productPage = new ProductDisplayAndCategories(driver);

        // Initialize ExtentReports
        test = ExtentManager.createTest("Product Categories and Display Test");
    }

    @Test(priority = 1)
    public void testLoginFunctionality() {
        test.info("Verifying the login functionality with valid credentials");

        try {
            String username = "subaguvi@gmail.com";
            String password = "subaguvi";
            productPage.login(username, password);
            productPage.loginClose();

            // Check if logged in by checking for logout button
            Assert.assertTrue(productPage.isLogoutButtonVisible(), "Logout button is not visible after login");
            test.pass("Login successful and Logout button is visible");
        } catch (Exception e) {
            test.fail("Login failed with valid credentials");
            takeScreenshot("testLoginFunctionality");
            throw e;
        }
    }
    
    
    @Test(priority = 2)
    public void testWelcomeText() {
        test.info("Verifying the presence of 'Welcome user' text");

        try {
            Assert.assertTrue(productPage.isWelcomeTextDisplayed(), "'Welcome user' text is not displayed on the homepage.");
            test.pass("'Welcome user' text is displayed successfully.");
        } catch (AssertionError e) {
            test.fail("'Welcome user' text is not displayed.");
            takeScreenshot("testWelcomeText");
            throw e;
        }
    }



    @Test(priority = 3)
    public void testMenuItems() {
        test.info("Verifying all menu items are displayed on the homepage");

        try {
            // Check if all menu items (Home, Contact, etc.) are displayed
            Assert.assertTrue(productPage.areMenuItemsDisplayed(), "Some menu items are missing.");
            test.pass("All menu items are displayed successfully.");
        } catch (AssertionError e) {
            test.fail("Menu items are not displayed.");
            takeScreenshot("testMenuItems");
            throw e;
        }
    }

    @Test(priority = 4)
    public void testCategories() {
        test.info("Verifying all product categories are displayed on the homepage");

        try {
            // Check if all product categories (Phones, Laptops, Monitors) are displayed
            Assert.assertTrue(productPage.areCategoriesDisplayed(), "Some categories are missing.");
            test.pass("All product categories are displayed successfully.");
        } catch (AssertionError e) {
            test.fail("Categories are not displayed.");
            takeScreenshot("testCategories");
            throw e;
        }
    }

    @Test(priority = 5)
    public void testLogo() {
        test.info("Verifying if the application logo is displayed on the homepage");

        try {
            // Check if the application logo is displayed
            Assert.assertTrue(productPage.isLogoDisplayed(), "Application logo is not displayed.");
            test.pass("Application logo is displayed successfully.");
        } catch (AssertionError e) {
            test.fail("Application logo is not displayed.");
            takeScreenshot("testLogo");
            throw e;
        }
    }
    
 
    @AfterClass
    public void tearDown() {
        driver.quit();
        ExtentManager.endReport();  // End the report after all tests are done
    }

    // Method to take a screenshot if a test fails
    private void takeScreenshot(String testName) {
        try {
            String screenshotPath = "test-output/ExtentReports/screenshots/" + testName + ".png";
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenshotPath));
            test.addScreenCaptureFromPath(screenshotPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package Tests;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import Pages.CartPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ExtentManager;

public class CartTest {
	
	WebDriver driver;
    CartPage cartPage;
    ExtentTest test;  // ExtentTest instance for logging test steps

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");

        // Initialize the ProductPage class
        cartPage = new CartPage(driver);

        // Initialize ExtentReports
        test = ExtentManager.createTest("Cart Functionality");
    }

    @Test(priority = 1)
    public void vertifyAbilityToDeleteItemFromCart() throws InterruptedException {
        test.info("Verifying ability to delete items from cart");

        try {
            cartPage.addProductOne();
            Thread.sleep(2000);
            cartPage.addToCart();
            Thread.sleep(2000);
            System.out.println("First Item Added To Cart");
            cartPage.addProductTwo();
            Thread.sleep(2000);
            cartPage.addToCart();
            Thread.sleep(2000);
            System.out.println("Second Item Added To Cart");
            System.out.println("========================================");
            cartPage.deleteItemFromCart();
            
            test.pass("Items is deleted successfully ");
        } catch (AssertionError e) {
            test.fail("Item is not deleted successfully");
            takeScreenshot("testProductDetails");
            throw e;
        }
    }

    @Test(priority = 2)
    public void verifyPriceAfterModification() throws InterruptedException {
        test.info("Verifying Total Price After Modification");

        try {
            
            Assert.assertEquals(cartPage.totalPriceAfterModification(),1, "Product price is not modified.");
            test.pass("Product Price is Modified successfully.");
        } catch (AssertionError e) {
            test.fail("Product Price is not Modified successfully.");
            takeScreenshot("PriceModificationInCart");
            throw e;
        }
    }
    
    @Test(priority = 3)
    public void verifyCartIsEmpty() {
    	test.info("Verifying whether the cart is empty after deleting all items from cart");
    	try {
    	Assert.assertEquals(cartPage.isCartEmpty(),true, "Cart is not empty");
    	test.pass("Cart Is Empty");
    	}
    	catch(AssertionError e){
    		test.fail("Cart Is Not Empty");
            takeScreenshot("PriceModificationInCart");
            throw e;
    	}
    }
    

    @AfterClass
    public void tearDown() {
        driver.quit();
        ExtentManager.endReport();  // End the report after all tests are done
    }

    // Method to take a screenshot if a test fails
    private void takeScreenshot(String testName) {
        try {
            String screenshotPath = "test-output/ExtentReports/screenshots/" + testName + ".png";
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenshotPath));
            test.addScreenCaptureFromPath(screenshotPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


package Tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import Pages.PurchasePage;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ExtentManager;

public class PurchaseTest {

	
	WebDriver driver;
    PurchasePage purchasePage;
    ExtentTest test;  // ExtentTest instance for logging test steps

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");

        // Initialize the ProductPage class
        purchasePage = new PurchasePage(driver);

        // Initialize ExtentReports
        test = ExtentManager.createTest("Purchase Functionality");
    }
    
    
    @Test(priority = 1)
    public void addItemsToCart() throws InterruptedException {
        test.info("Items Added To cart or Not");

        try {
            purchasePage.addProductToCart();
            Thread.sleep(2000);
            purchasePage.placeOrder();
            Thread.sleep(2000);
            
            test.pass("Items is added successfully ");
        } catch (AssertionError e) {
            test.fail("Item is not added successfully");
            takeScreenshot("testProductDetails");
            throw e;
        }
    }
    
    
    @Test(priority = 2)
    public void testCompletePurchase() {
    	test.info("Verifying completion of successfull purchase");

        try {
        // Step 1: Enter user details
        String name = "John Doe";
        String country = "USA";
        String city = "New York";
        purchasePage.enterUserDetails(name, country, city);
        
        // Step 2: Enter payment details
        String cardNumber = "4111111111111111"; 
        String expiryMonth = "12";
        String expiryYear = "2026";
        purchasePage.enterPaymentDetails(cardNumber, expiryMonth, expiryYear);
        
        // Step 3: Complete the purchase
        purchasePage.clickPurchaseButton();
        
        // Step 4: Verify purchase confirmation message
//        boolean isConfirmationDisplayed = purchasePage.verifyPurchaseConfirmation();
        
        // Assert that the confirmation message is displayed
        Assert.assertEquals(purchasePage.verifyPurchaseConfirmation(),"Thank you for your purchase!","Successfull Purchase message is not displayed");
        test.pass("Successfully Purchased");
    }
        catch (AssertionError e) {
        	test.fail("Purcahse is not Successfull");
            takeScreenshot("test purchase details");
            throw e;
        }
}
	
    @AfterClass
    public void tearDown() {
        driver.quit();
        ExtentManager.endReport();  // End the report after all tests are done
    }

    private void takeScreenshot(String testName) {
        try {
            String screenshotPath = "test-output/ExtentReports/screenshots/" + testName + ".png";
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenshotPath));
            test.addScreenCaptureFromPath(screenshotPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
}

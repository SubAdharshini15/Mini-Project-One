package Tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import utils.ExtentManager;
import com.aventstack.extentreports.ExtentTest;
import Pages.ProductDetailsPage;
import io.github.bonigarcia.wdm.WebDriverManager;


public class ProductDetailsPageTest {

    WebDriver driver;
    ProductDetailsPage productPage;
    ExtentTest test;  // ExtentTest instance for logging test steps

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");

        // Initialize the ProductPage class
        productPage = new ProductDetailsPage(driver);

        // Initialize ExtentReports
        test = ExtentManager.createTest("Product Details and Adding to Cart Test");
    }

    @Test(priority = 1)
    public void testProductDetails() throws InterruptedException {
        test.info("Verifying the product details accuracy");

        try {
            // Click on a product
            productPage.clickOnProduct();
            Thread.sleep(2000);
            
            // Verifying product details (name, price, description)
            String expectedName = "Nokia lumia 1520";  // Example product name
            String expectedPrice = "$820 *includes tax";  // Example price
            String expectedDescription = "Product description The Nokia Lumia 1520 is powered by 2.2GHz quad-core Qualcomm Snapdragon 800 processor and it comes with 2GB of RAM.";
            
            Assert.assertTrue(productPage.verifyProductDetails(expectedName, expectedPrice, expectedDescription),
                    "Product details are incorrect.");
            test.pass("Product details are correct.");
        } catch (AssertionError e) {
            test.fail("Product details are incorrect.");
            takeScreenshot("testProductDetails");
            throw e;
        }
    }

    @Test(priority = 2)
    public void testAddToCart() throws InterruptedException {
        test.info("Verifying adding the product to cart");

        try {
            // Add the product to the cart
            productPage.addToCart();
            Thread.sleep(2000);
            // Verify cart item count
            int cartItemCount = productPage.getCartItemCount();
            Assert.assertEquals(cartItemCount, 1, "Product was not added to the cart.");
            test.pass("Product added to the cart successfully.");
        } catch (AssertionError e) {
            test.fail("Product was not added to the cart.");
            takeScreenshot("testAddToCart");
            throw e;
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
        ExtentManager.endReport();  // End the report after all tests are done
    }

    // Method to take a screenshot if a test fails
    private void takeScreenshot(String testName) {
        try {
            String screenshotPath = "test-output/ExtentReports/screenshots/" + testName + ".png";
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenshotPath));
            test.addScreenCaptureFromPath(screenshotPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package Tests;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import Pages.LogOutPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ExtentManager;

public class LogOutTest {

	WebDriver driver;
    LogOutPage logoutPage;
    ExtentTest test;  

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");

        // Initialize the LogOutPage class
        logoutPage = new LogOutPage(driver);

        // Initialize ExtentReports
        test = ExtentManager.createTest("Login Functionality Test");
    }

    @Test(priority = 1)
    public void testLoginButtonVisibility() {
        test.info("Verifying visibility of the Log in button");

        try {
            // Check if the Log in button is visible
            Assert.assertTrue(logoutPage.isLoginButtonVisible(), "Log in button is not visible");
            test.pass("Log in button is visible");
        } catch (AssertionError e) {
            test.fail("Log in button is not visible");
            takeScreenshot("testLoginButtonVisibility");
            throw e;
        }
    }

    @Test(priority = 2)
    public void testLoginButtonClick() {
        test.info("Verifying that the Log in button is clickable");

        try {
            // Click on the Log in button
            logoutPage.clickLoginButton();
            test.pass("Log in button clicked");
        } catch (Exception e) {
            test.fail("Error occurred while clicking Log in button");
            takeScreenshot("testLoginButtonClick");
            throw e;
        }
    }

    @Test(priority = 3)
    public void testLoginFunctionality() {
        test.info("Verifying the login functionality with valid credentials");

        try {
            String username = "subaguvi@gmail.com";
            String password = "subaguvi";
            logoutPage.login(username, password);
            logoutPage.loginClose();

            // Check if logged in by checking for logout button
            Assert.assertTrue(logoutPage.isLogoutButtonVisible(), "Logout button is not visible after login");
            test.pass("Login successful and Logout button is visible");
        } catch (Exception e) {
            test.fail("Login failed with valid credentials");
            takeScreenshot("testLoginFunctionality");
            throw e;
        }
    }

    @Test(priority = 4)
    public void testRedirectionToHomepage() {
        test.info("Verifying redirection to homepage after login");

        try {
            logoutPage.goToHomePage();
            String expectedUrl = "https://www.demoblaze.com/index.html";
            Assert.assertEquals(driver.getCurrentUrl(), expectedUrl, "Redirection to homepage failed");
            test.pass("Successfully redirected to homepage after login");
        } catch (Exception e) {
            test.fail("Redirection to homepage failed");
            takeScreenshot("testRedirectionToHomepage");
            throw e;
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
        ExtentManager.endReport();  
    }

    // Method to take a screenshot if a test fails
    private void takeScreenshot(String testName) {
        try {
            String screenshotPath = "test-output/ExtentReports/screenshots/" + testName + ".png";
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenshotPath));
            test.addScreenCaptureFromPath(screenshotPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
